package com.abudawod.kucc;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.squareup.picasso.Picasso;

import java.util.List;
import java.util.zip.Inflater;

import de.hdodenhof.circleimageview.CircleImageView;

public class ProductAdapter extends FirebaseRecyclerAdapter<ShowDoctor, ProductAdapter.ProductViewHolder> {



    public ProductAdapter(@NonNull FirebaseRecyclerOptions<ShowDoctor> options) {
        super(options);
    }

    @Override
    protected void onBindViewHolder(@NonNull ProductViewHolder holder, int i, @NonNull ShowDoctor showDoctor) {
            holder.Name.setText(showDoctor.getName());
            holder.Speciality.setText(showDoctor.getSpeciality()+" Specialist");
            Picasso.get().load(showDoctor.getProfile_Image()).placeholder(R.drawable.doctor).into(holder.Image);
    }

    @NonNull
    @Override
    public ProductViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.users_display_layout,parent,false);

        return new ProductViewHolder(view);
    }

    class ProductViewHolder extends RecyclerView.ViewHolder {

        CircleImageView Image;
        TextView Name,Speciality;


        public ProductViewHolder(@NonNull View itemView) {
            super(itemView);
            Image=itemView.findViewById(R.id.doctor_list_profile_image);
            Name=itemView.findViewById(R.id.doctor_list_name);
            Speciality=itemView.findViewById(R.id.doctor_list_special);
        }
    }
}
