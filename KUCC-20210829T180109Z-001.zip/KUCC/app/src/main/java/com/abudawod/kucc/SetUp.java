package com.abudawod.kucc;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Person;
import android.app.ProgressDialog;
import android.content.ContentResolver;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.Continuation;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.OnProgressListener;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.squareup.picasso.Picasso;
import com.theartofdev.edmodo.cropper.CropImage;
import com.theartofdev.edmodo.cropper.CropImageActivity;
import com.theartofdev.edmodo.cropper.CropImageView;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Set;

import de.hdodenhof.circleimageview.CircleImageView;

public class SetUp extends AppCompatActivity implements CompoundButton.OnCheckedChangeListener, View.OnClickListener {
    Switch aSwitch=null;
    Button SpecialityButton,Save;
    EditText FullName,Contact,Age;
    CircleImageView profilePicture;
    FirebaseAuth mAuth=FirebaseAuth.getInstance();
    DatabaseReference databaseReference;
    StorageReference UserProfileImageRef,extraa;
    FirebaseStorage storage;
    final static int Gallery_Pick=1;

    TextView Selected;
    String spcl,CurrentUserID,downloadUri,link_down;
    String[] list;
    private Uri filePath;

    boolean [] checkedlist;
    ArrayList<Integer> spitem=new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_set_up);
        SpecialityButton=findViewById(R.id.doctor_speciality);
        aSwitch=findViewById(R.id.register_as_doctor);
        profilePicture=findViewById(R.id.choose_user_profile_picture);
        profilePicture.setOnClickListener(this);
        UserProfileImageRef= FirebaseStorage.getInstance().getReference().child("Profile_Images");

        Save=findViewById(R.id.save_user_info);
        storage=FirebaseStorage.getInstance();

        Selected=findViewById(R.id.show_speciality);
        Contact=findViewById(R.id.register_phone_number);
        FullName=findViewById(R.id.register_user_name);
        Age=findViewById(R.id.register_date_of_birth);
        CurrentUserID=mAuth.getCurrentUser().getUid();
        aSwitch.setOnCheckedChangeListener(this);
        list=getResources().getStringArray(R.array.Specialist);
        checkedlist=new boolean[list.length];
        SpecialityButton.setOnClickListener(this);
        Save.setOnClickListener(this);
        Save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               // upload();
                savepatient();
            }
        });
        
        profilePicture.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent galleryIntent=new Intent();
                galleryIntent.setAction(Intent.ACTION_GET_CONTENT);
                galleryIntent.setType("image/*");
                startActivityForResult(galleryIntent,Gallery_Pick);
            }
        });



    }


    @Override
    protected void onActivityResult(int requestCode,int resultCode,Intent data)
    {

        super.onActivityResult(requestCode,resultCode,data);

        if (requestCode == Gallery_Pick  && resultCode == RESULT_OK && data != null)
        {

           //Uri imageUri=data.getData();
            CropImage.activity().setGuidelines(CropImageView.Guidelines.ON).setAspectRatio(1,1).start(SetUp.this);

        }
        if(requestCode== CropImage.CROP_IMAGE_ACTIVITY_REQUEST_CODE)
        {
            CropImage.ActivityResult result=CropImage.getActivityResult(data);
            if(resultCode==RESULT_OK)
            {
                final Uri resultUri=result.getUri();
                final StorageReference filePath=UserProfileImageRef.child(mAuth.getCurrentUser().getUid()+".jpg");

                filePath.putFile(resultUri).addOnCompleteListener(new OnCompleteListener<UploadTask.TaskSnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<UploadTask.TaskSnapshot> task) {
                        if(task.isSuccessful())
                        {
                           // databaseReference=FirebaseDatabase.getInstance().getReference().child("User").child(mAuth.getCurrentUser().getUid());
                            Toast.makeText(SetUp.this,"Image uploaded",Toast.LENGTH_SHORT).show();

                                 // extraa=storage.getReferenceFromUrl("gs://kucc-8eeca.appspot.com/Profile_Images/"+mAuth.getCurrentUser().getUid()+".jpg");
                            //final String downloadUri=task.getResult().getMetadata().getReference().getDownloadUrl().toString();

                            final StorageReference ref=FirebaseStorage.getInstance().getReference().child("User_Images").child(mAuth.getCurrentUser().getUid()+".jpg");

                            final UploadTask uploadTask=filePath.putFile(resultUri);
                            uploadTask.addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                                @Override
                                public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                                    taskSnapshot.getStorage().getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
                                        @Override
                                        public void onSuccess(Uri uri) {
                                            String downloadurl=uri.toString();
                                            link_down=downloadurl;
                                            databaseReference=FirebaseDatabase.getInstance().getReference().child("User").child(mAuth.getCurrentUser().getUid());
                                            //databaseReference.child("Profile_Image").setValue(downloadurl);
                                            Picasso.get().load(downloadurl).placeholder(R.drawable.doctor).into(profilePicture);


                                        }
                                    });
                                }
                            });













                        }
                    }
                });
            }
            else
            {
                Toast.makeText(SetUp.this,"Failed to upload image",Toast.LENGTH_SHORT).show();
            }
        }
    }


    @Override
    public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
        if (isChecked){

            SpecialityButton.setVisibility(View.VISIBLE);
            Save.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    saveDoctor();
                   // upload();
                }
            });
            

        }
        else {

            SpecialityButton.setVisibility(View.INVISIBLE);
            Save.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                   // upload();
                    savepatient();

                }
            });
        }
    }



    private void savepatient() {
        String FName=FullName.getText().toString();
        String Con=Contact.getText().toString();
        String boyosh=Age.getText().toString();

        if(FName.isEmpty()){
            Toast.makeText(SetUp.this,"Enter Your Full Name",Toast.LENGTH_SHORT).show();
        }
        else if(Con.isEmpty()){
            Toast.makeText(SetUp.this,"Enter Your Contact Number",Toast.LENGTH_SHORT).show();

        }
        else if(boyosh.isEmpty()){
            Toast.makeText(SetUp.this,"Enter Your Age",Toast.LENGTH_SHORT).show();
        }
        else {
            databaseReference=FirebaseDatabase.getInstance().getReference().child("User").child(CurrentUserID);
            HashMap userMap=new HashMap();
            userMap.put("Name",FName);
            userMap.put("Contact_Number",Con);
            userMap.put("Age",boyosh);
            userMap.put("ProfilePicture",extraa);
            userMap.put("Status","Patient");
            userMap.put("UID",mAuth.getCurrentUser().getUid());
           // upload();


            databaseReference.updateChildren(userMap).addOnCompleteListener(new OnCompleteListener() {
                @Override
                public void onComplete(@NonNull Task task) {
                    if(task.isSuccessful()){
                        sendusermain();
                        Toast.makeText(SetUp.this,"Your profile created Successfully",Toast.LENGTH_SHORT).show();
                    }
                    else
                    {
                        String message=task.getException().getMessage();
                        Toast.makeText(SetUp.this,"Error: "+message,Toast.LENGTH_SHORT).show();


                    }
                }
            });

        }

    }



    private void sendusermain() {
        Intent intent=new Intent(SetUp.this,MainActivity.class);
        startActivity(intent);
        finish();
    }

    private void saveDoctor() {
        String FName=FullName.getText().toString();
        String Con=Contact.getText().toString();
        String boyosh=Age.getText().toString();
        String SP=Selected.getText().toString();
        if(FName.isEmpty()){
            Toast.makeText(SetUp.this,"Enter Your Full Name",Toast.LENGTH_SHORT).show();
        }
        else if(Con.isEmpty()){
            Toast.makeText(SetUp.this,"Enter Your Contact Number",Toast.LENGTH_SHORT).show();

        }
        else if(SP.isEmpty())
        {
            Toast.makeText(SetUp.this,"Enter Your Speciality",Toast.LENGTH_SHORT).show();
        }
        else if(boyosh.isEmpty()){
            Toast.makeText(SetUp.this,"Enter Your Age",Toast.LENGTH_SHORT).show();
        }
        else {
            DatabaseReference newpath=FirebaseDatabase.getInstance().getReference().child("Doctor").child(CurrentUserID);
            databaseReference=FirebaseDatabase.getInstance().getReference().child("User").child(CurrentUserID);
            HashMap userMap=new HashMap();
            userMap.put("Name",FName);
            userMap.put("Contact_Number",Con);
            userMap.put("Age",boyosh);
            userMap.put("Profile_Image",link_down);
            userMap.put("Speciality",SP);
            userMap.put("Status","Doctor");
            userMap.put("UID",mAuth.getCurrentUser().getUid());

            newpath.updateChildren(userMap);
            databaseReference.updateChildren(userMap).addOnCompleteListener(new OnCompleteListener() {
                @Override
                public void onComplete(@NonNull Task task) {
                  if(task.isSuccessful()){
                      sendusermain();
                      Toast.makeText(SetUp.this,"Your profile created Successfully",Toast.LENGTH_SHORT).show();
                  }
                  else
                  {
                      String message=task.getException().getMessage();
                      Toast.makeText(SetUp.this,"Error: "+message,Toast.LENGTH_SHORT).show();


                  }
                }
            });

        }
    }

    @Override
    public void onClick(View v) {
        Speciality();
    }

    private void Speciality() {
        AlertDialog.Builder builder=new AlertDialog.Builder( SetUp.this);
        builder.setTitle("Specialist On");
        builder.setMultiChoiceItems(list, checkedlist, new DialogInterface.OnMultiChoiceClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which, boolean isChecked) {
                if(isChecked){
                    if(!spitem.contains(which)){
                        spitem.add(which);
                    }
                    else
                    {
                        spitem.remove(which);
                    }
                }
            }
        });
        builder.setCancelable(false);
        builder.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                String item="";
                for(int i=0;i<spitem.size();i++){
                    item=item+list[spitem.get(i)];
                    if(i !=spitem.size()-1){
                        item=item+", ";
                    }
                }
                Selected.setText(item);
                spcl=item;
            }
        });
        builder.setNegativeButton("Dismiss", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });
        builder.setNeutralButton("Clear All", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                for(int i=0;i<checkedlist.length;i++){
                    checkedlist[i]=false;
                    spitem.clear();
                    Selected.setText("");

                }
            }
        });
        AlertDialog mDialog=builder.create();
        mDialog.show();
    }
}
