package com.abudawod.kucc;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class AppointmentNotification extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_appointment_notification);
    }
}
