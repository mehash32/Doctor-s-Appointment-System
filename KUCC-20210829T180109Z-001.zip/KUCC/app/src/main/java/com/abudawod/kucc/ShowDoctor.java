package com.abudawod.kucc;

public class ShowDoctor {
    String Age,Contact_Number,Name,Profile_Image,Speciality,UID,Status;
    public ShowDoctor(){

    }

    public ShowDoctor(String age, String contact_Number, String name, String profile_Image, String speciality, String UID, String status) {
        Age = age;
        Contact_Number = contact_Number;
        Name = name;
        Profile_Image = profile_Image;
        Speciality = speciality;
        this.UID = UID;
        Status = status;
    }

    public String getAge() {
        return Age;
    }

    public void setAge(String age) {
        Age = age;
    }

    public String getContact_Number() {
        return Contact_Number;
    }

    public void setContact_Number(String contact_Number) {
        Contact_Number = contact_Number;
    }

    public String getName() {
        return Name;
    }

    public void setName(String name) {
        Name = name;
    }

    public String getProfile_Image() {
        return Profile_Image;
    }

    public void setProfile_Image(String profile_Image) {
        Profile_Image = profile_Image;
    }

    public String getSpeciality() {
        return Speciality;
    }

    public void setSpeciality(String speciality) {
        Speciality = speciality;
    }

    public String getUID() {
        return UID;
    }

    public void setUID(String UID) {
        this.UID = UID;
    }

    public String getStatus() {
        return Status;
    }

    public void setStatus(String status) {
        Status = status;
    }
}
