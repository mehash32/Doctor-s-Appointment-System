package com.abudawod.kucc;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.squareup.picasso.Picasso;

import de.hdodenhof.circleimageview.CircleImageView;

public class Profile extends AppCompatActivity {
    private TextView Name,Contact,Age,Specialist;
    private ImageView Notification,share;
    private CircleImageView Profile_picture;
    FirebaseAuth mAuth=FirebaseAuth.getInstance();
    DatabaseReference databaseReference,dbref;
    FirebaseStorage storage=FirebaseStorage.getInstance();
    String CurrentUser=mAuth.getCurrentUser().getUid();
    String link,username;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);
        Notification=findViewById(R.id.my_profile_notification);
        Name=findViewById(R.id.my_profile_name);
        Contact=findViewById(R.id.my_profile_contact);
        Age=findViewById(R.id.my_profile_age);
        Profile_picture=findViewById(R.id.my_profile_pic);
        Specialist=findViewById(R.id.my_profile_speciality);
        databaseReference= FirebaseDatabase.getInstance().getReference().child("User").child(CurrentUser);
        //dbref=storage.getReference().child()
        //final StorageReference storageReference=storage.getReferenceFromUrl("gs://kucc-8eeca.appspot.com/Profile_Images/"+mAuth.getCurrentUser().getUid()+".jpg");
        share=findViewById(R.id.my_profile_share);

        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot)
            {
                if(dataSnapshot.child("Name").exists()) {
                    String name=dataSnapshot.child("Name").getValue().toString();
                    Name.setText(name);
                    username=name;

                }
                if(dataSnapshot.child("Contact_Number").exists()) {
                        String con=dataSnapshot.child("Contact_Number").getValue().toString();
                        Contact.setText("Contact: "+con);
                }
                if(dataSnapshot.child("Age").exists()) {
                    String boyos=dataSnapshot.child("Age").getValue().toString();
                    Age.setText("Age: "+boyos);
                }
                if(dataSnapshot.child("Speciality").exists()){
                    String sp=dataSnapshot.child("Speciality").getValue().toString();
                    Specialist.setText(sp+" Specialist");
                    share.setVisibility(View.VISIBLE);
                }
                if(dataSnapshot.child("Profile_Image").exists()){
                    String image=dataSnapshot.child("Profile_Image").getValue().toString();
                    link=image;
                    Picasso.get().load(image).placeholder(R.drawable.doctor).into(Profile_picture);

                    }

                }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
        share.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(Profile.this,Share.class);
                intent.putExtra("image",link);
                intent.putExtra("Name",username);
                startActivity(intent);
            }
        });

        Notification.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(Profile.this,AppointmentNotification.class);
                startActivity(intent);
            }
        });


    }
}
