package com.abudawod.kucc;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class Register extends AppCompatActivity {
    EditText email,password, compassed;
    Button register;
    FirebaseAuth mAuth=FirebaseAuth.getInstance();
    private ProgressDialog progressDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        email=findViewById(R.id.register_email);
        progressDialog=new ProgressDialog(this);
        password=findViewById(R.id.register_password);
        compassed =findViewById(R.id.confirm_register_password);
        register=findViewById(R.id.register_button);

        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                registeranuser();
            }
        });


    }

    private void registeranuser() {
        String mail=email.getText().toString();
        String pass=password.getText().toString();
        String Confirm = compassed.getText().toString();

        if(TextUtils.isEmpty(mail)){
            Toast.makeText(Register.this,"Please Enter an Email",Toast.LENGTH_SHORT).show();

        }
        else if(TextUtils.isEmpty(pass)){
            Toast.makeText(Register.this,"Please Type your password",Toast.LENGTH_SHORT).show();
        }
        else if(TextUtils.isEmpty(Confirm)){
            Toast.makeText(Register.this,"Please Confirm your password",Toast.LENGTH_SHORT).show();

        }

        else {
            if(TextUtils.equals(pass,Confirm)){
                progressDialog.setTitle("Creating account");
                progressDialog.setMessage("Please wait for sometime");
                progressDialog.show();
                progressDialog.setCanceledOnTouchOutside(true);

                mAuth.createUserWithEmailAndPassword(mail,pass).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        Toast.makeText(Register.this,"Registered Successfully",Toast.LENGTH_SHORT).show();
                        progressDialog.dismiss();
                        Intent intent=new Intent(Register.this,SetUp.class);
                        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                        startActivity(intent);
                        finish();
                    }
                }).addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        progressDialog.dismiss();
                        Toast.makeText(Register.this,"Error Occured: "+e,Toast.LENGTH_SHORT).show();

                    }
                });
            }
            else {
                Toast.makeText(Register.this,"Password does not matched",Toast.LENGTH_SHORT).show();

            }

        }
    }
    @Override
    protected void onStart() {
        super.onStart();
        FirebaseUser firebaseUser=mAuth.getCurrentUser();
        if(firebaseUser!=null)
        {
            sendtomain();
        }
    }

    private void sendtomain() {
        Intent intent=new Intent(Register.this,MainActivity.class);
        startActivity(intent);
        finish();

    }
}
