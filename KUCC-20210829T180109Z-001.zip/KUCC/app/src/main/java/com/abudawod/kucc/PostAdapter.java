package com.abudawod.kucc;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.squareup.picasso.Picasso;

import de.hdodenhof.circleimageview.CircleImageView;

public class PostAdapter extends FirebaseRecyclerAdapter<Posts, PostAdapter.PostViewHolder> {

    public PostAdapter(@NonNull FirebaseRecyclerOptions<Posts> options) {
        super(options);
    }

    @Override
    protected void onBindViewHolder(@NonNull PostViewHolder holder, int i, @NonNull Posts posts) {
       holder.username.setText(posts.getUserName());
       holder.status.setText(posts.getStatus());
       holder.date.setText(posts.getDate());
       holder.time.setText(posts.getTime());
       Picasso.get().load(posts.getUserImage()).placeholder(R.drawable.doctor).into(holder.userImage);
        //Picasso.get().load(posts.getImage()).placeholder(R.drawable.doctor).into(holder.postImage);

    }

    @NonNull
    @Override
    public PostViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.all_post_layout,parent,false);

        return new PostViewHolder(view);
    }

    class PostViewHolder extends RecyclerView.ViewHolder{
        CircleImageView userImage;
        ImageView postImage;
        TextView status,date,time,username;
        String userID;

        public PostViewHolder(@NonNull View itemView) {
            super(itemView);
            userImage=itemView.findViewById(R.id.post_user_id);
           // postImage=itemView.findViewById(R.id.posted_image);
            status=itemView.findViewById(R.id.posted_story);
            date=itemView.findViewById(R.id.post_update_date);
            time=itemView.findViewById(R.id.post_update_time);
            username=itemView.findViewById(R.id.post_user_name);

        }
    }
}
