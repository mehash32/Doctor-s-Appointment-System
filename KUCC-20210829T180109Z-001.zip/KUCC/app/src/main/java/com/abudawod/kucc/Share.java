package com.abudawod.kucc;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.appcompat.widget.Toolbar;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.squareup.picasso.Picasso;
import com.theartofdev.edmodo.cropper.CropImage;
import com.theartofdev.edmodo.cropper.CropImageView;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.HashMap;

public class Share extends AppCompatActivity {
    private Toolbar mtoolbar;
    private EditText editText;
    private ImageView imageView;
    private Button post;
    StorageReference post_storage;
    FirebaseDatabase firebaseDatabase;
    FirebaseAuth mAuth=FirebaseAuth.getInstance();
    final static int Gallery_Pick=1;
    String photo=null;
    String downloadurl=null,savecurrentDate,savecurrentTime;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_share);
        mtoolbar=findViewById(R.id.doc_share_toolbar);
        setSupportActionBar(mtoolbar);
        getSupportActionBar().setTitle("Share");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        post=findViewById(R.id.share_button);
        //imageView=findViewById(R.id.share_attach_image);
        editText=findViewById(R.id.share_information);
        post_storage=FirebaseStorage.getInstance().getReference().child("Post");

        Calendar calendar=Calendar.getInstance();
        SimpleDateFormat currentTime=new SimpleDateFormat("hh:mm:ss");
        savecurrentTime=currentTime.format(calendar.getTime());

        Calendar calendarr=Calendar.getInstance();
        SimpleDateFormat currentdate=new SimpleDateFormat("dd-MMM-YYYY");
        savecurrentDate=currentdate.format(calendarr.getTime());



        post.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                update_post();
            }
        });
      /*  imageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent galleryIntent=new Intent();
                photo="select";
                galleryIntent.setAction(Intent.ACTION_GET_CONTENT);
                galleryIntent.setType("image/*");
                startActivityForResult(galleryIntent,Gallery_Pick);
            }
        });*/


    }
   /* @Override
    protected void onActivityResult(int requestCode,int resultCode,Intent data)
    {

        super.onActivityResult(requestCode,resultCode,data);

        if (requestCode == Gallery_Pick  && resultCode == RESULT_OK && data != null)
        {

            //Uri imageUri=data.getData();
            CropImage.activity().setGuidelines(CropImageView.Guidelines.ON).setAspectRatio(1,1).start(Share.this);

        }
        if(requestCode== CropImage.CROP_IMAGE_ACTIVITY_REQUEST_CODE)
        {
            CropImage.ActivityResult result=CropImage.getActivityResult(data);
            if(resultCode==RESULT_OK)
            {
                final Uri resultUri=result.getUri();
                final StorageReference filePath=post_storage.child(mAuth.getCurrentUser().getUid()+".jpg");

                filePath.putFile(resultUri).addOnCompleteListener(new OnCompleteListener<UploadTask.TaskSnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<UploadTask.TaskSnapshot> task) {
                        if(task.isSuccessful())
                        {
                            // databaseReference=FirebaseDatabase.getInstance().getReference().child("User").child(mAuth.getCurrentUser().getUid());
                            Toast.makeText(Share.this,"Image uploaded",Toast.LENGTH_SHORT).show();

                            // extraa=storage.getReferenceFromUrl("gs://kucc-8eeca.appspot.com/Profile_Images/"+mAuth.getCurrentUser().getUid()+".jpg");
                            //final String downloadUri=task.getResult().getMetadata().getReference().getDownloadUrl().toString();

                            //final StorageReference ref= FirebaseStorage.getInstance().getReference().child("Post_Image").child(mAuth.getCurrentUser().getUid()+".jpg");

                            final UploadTask uploadTask=filePath.putFile(resultUri);
                            uploadTask.addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                                @Override
                                public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                                    taskSnapshot.getStorage().getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
                                        @Override
                                        public void onSuccess(Uri uri) {
                                            downloadurl=uri.toString();
                                           //DatabaseReference databaseReference= FirebaseDatabase.getInstance().getReference().child("Post").child(mAuth.getCurrentUser().getUid());
                                           // databaseReference.child("Image").setValue(downloadurl);
                                            //Picasso.with(Share.this).load(downloadurl).placeholder(R.drawable.doctor).into(profilePicture);


                                        }
                                    });
                                }
                            });













                        }
                    }
                });
            }
            else
            {
                Toast.makeText(Share.this,"Failed to upload image",Toast.LENGTH_SHORT).show();
            }
        }
    }*/



    private void update_post() {
        String story=editText.getText().toString();
       // String Url=downloadurl;


        String ref;
        ref=savecurrentDate+savecurrentTime;
        String Link=getIntent().getStringExtra("image");
        String user_name=getIntent().getStringExtra("Name");

       // DatabaseReference databaseReference= FirebaseDatabase.getInstance().getReference().child("Post").child(mAuth.getCurrentUser().getUid());
        HashMap userMap=new HashMap();
            //userMap.put("Image",downloadurl);
            userMap.put("Status",story);
            userMap.put("Date",savecurrentDate);
            userMap.put("Time",savecurrentTime);
            userMap.put("UserImage",Link);
            userMap.put("UserName",user_name);

        DatabaseReference databaseReference=FirebaseDatabase.getInstance().getReference().child("Post").child(ref);
        databaseReference.updateChildren(userMap).addOnCompleteListener(new OnCompleteListener() {
            @Override
            public void onComplete(@NonNull Task task) {
                if(task.isSuccessful()){
                    Intent intent=new Intent(Share.this,MainActivity.class);
                    startActivity(intent);
                    Toast.makeText(Share.this,"Posted Successfully",Toast.LENGTH_SHORT).show();
                }
                else
                {
                    String message=task.getException().getMessage();
                    Toast.makeText(Share.this,"Error: "+message,Toast.LENGTH_SHORT).show();


                }
            }
        });

    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int id=item.getItemId();
        if(id == android.R.id.home)
        {
            Intent intent=new Intent(Share.this,MainActivity.class);
            startActivity(intent);
        }
        return super.onOptionsItemSelected(item);
    }
}
