package com.abudawod.kucc;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;


import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.material.navigation.NavigationView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FileDownloadTask;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.squareup.picasso.Picasso;

import java.io.File;
import java.io.IOException;

import de.hdodenhof.circleimageview.CircleImageView;

public class MainActivity extends AppCompatActivity {
    private NavigationView navigationView;
    private DrawerLayout drawerLayout;
    private RecyclerView postlist;
    private PostAdapter adapter;
    private Toolbar toolbar;
    CircleImageView circleImageView;
    DatabaseReference databaseReference,dbref;
    FirebaseStorage firebaseStorage;
    private ActionBarDrawerToggle actionBarDrawerToggle;
    FirebaseAuth mAuth=FirebaseAuth.getInstance();
    TextView UserName;
    //String Current_User_ID;







    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        drawerLayout=findViewById(R.id.drawer_layout);
        navigationView=findViewById(R.id.nav_view);
        toolbar=findViewById(R.id.main_page_toolbar);
        setSupportActionBar(toolbar);
        firebaseStorage=FirebaseStorage.getInstance();
        getSupportActionBar().setTitle("Home");

        databaseReference= FirebaseDatabase.getInstance().getReference().child("User");


        postlist=findViewById(R.id.all_user_post_list);
        postlist.setLayoutManager(new LinearLayoutManager(this));
        //postlist.setHasFixedSize(true);
        FirebaseRecyclerOptions<Posts> options=
                new FirebaseRecyclerOptions.Builder<Posts>()
                        .setQuery(FirebaseDatabase.getInstance()
                                .getReference().child("Post"),Posts.class)
                        .build();
        adapter=new PostAdapter(options);
        postlist.setAdapter(adapter);






        actionBarDrawerToggle=new ActionBarDrawerToggle(MainActivity.this,drawerLayout,R.string.drawer_open,R.string.drawer_close);
        drawerLayout.addDrawerListener(actionBarDrawerToggle);
        actionBarDrawerToggle.syncState();
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        View navView=navigationView.inflateHeaderView(R.layout.navigation_header);
        circleImageView=navView.findViewById(R.id.nav_profile_image);
        UserName=navView.findViewById(R.id.nav_user_name);

        String uu=mAuth.getCurrentUser().getUid();

            if(uu.isEmpty()){

            }
            else
            {
                databaseReference.child(uu).addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        if(dataSnapshot.child("Name").exists()){
                            String user_name=dataSnapshot.child("Name").getValue().toString();

                            UserName.setText(user_name);
                            //Picasso.with(MainActivity.this).load(image).placeholder(R.drawable.doctor).into(circleImageView);

                        }
                        if(dataSnapshot.child("Profile_Image").exists()){
                            String image=dataSnapshot.child("Profile_Image").getValue().toString();
                            Picasso.get().load(image).placeholder(R.drawable.doctor).into(circleImageView);

                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {

                    }
                });

            }



        navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
               UserMenuSelector(menuItem);
                return false;
            }
        });
    }




    @Override
    protected void onStart() {
        super.onStart();
        adapter.startListening();
        //sendLogInActivity();
       FirebaseUser firebaseUser=mAuth.getCurrentUser();
        if(firebaseUser==null)
       {
        sendLogInActivity();
       }
       else
       {
         CheckUserExistance();
       }
    }

   private void CheckUserExistance() {
        final String Current_User_Id=mAuth.getCurrentUser().getUid();


        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                if(!dataSnapshot.hasChild(Current_User_Id)){
                    sendtosetup();
                }

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }

    private void sendtosetup() {
        Intent intent=new Intent(MainActivity.this,SetUp.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
        finish();

    }

    private void sendLogInActivity() {
        Intent intent=new Intent(MainActivity.this,Login.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
        finish();
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if(actionBarDrawerToggle.onOptionsItemSelected(item)){
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    private void UserMenuSelector(MenuItem menuItem) {
        switch (menuItem.getItemId()){
            case R.id.menu_profile:
                sendMyProfile();
                break;
            case R.id.menu_doctor:
                Intent intent=new Intent(MainActivity.this,DoctorList.class);
                startActivity(intent);
                break;
            case R.id.menu_emergency:
                break;
            case R.id.menu_ambulance:
                break;
            case R.id.menu_about_us:
                sendaboutus();
                break;
            case R.id.menu_log_out:
                mAuth.signOut();
                sendLogInActivity();
                break;

        }

    }

    private void sendMyProfile() {
        Intent intent=new Intent(MainActivity.this,Profile.class);
        //intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);


    }

    private void sendaboutus() {
        Intent intent=new Intent(MainActivity.this,AboutUs.class);
        //intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
        finish();
    }




}
