package com.abudawod.kucc;

public class Posts {
    private String Status,UserImage,UserName,Time,Date;
    public Posts(){

    }

    public Posts(String status, String userImage, String userName, String time, String date) {
        Status = status;
        UserImage = userImage;
        UserName = userName;
        Time = time;
        Date = date;
    }

    public String getStatus() {
        return Status;
    }

    public void setStatus(String status) {
        Status = status;
    }

    public String getUserImage() {
        return UserImage;
    }

    public void setUserImage(String userImage) {
        UserImage = userImage;
    }

    public String getUserName() {
        return UserName;
    }

    public void setUserName(String userName) {
        UserName = userName;
    }

    public String getTime() {
        return Time;
    }

    public void setTime(String time) {
        Time = time;
    }

    public String getDate() {
        return Date;
    }

    public void setDate(String date) {
        Date = date;
    }
}
